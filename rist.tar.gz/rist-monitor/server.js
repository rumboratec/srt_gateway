const express = require("express");
const WebSocket = require("ws");
const {spawn} = require("child_process");
const si = require("systeminformation");
const path = require("path");


const app = express();

app.use(express.json());
app.use(express.static("public"));


const server = app.listen(3000,()=>{
    console.log("http://localhost:3000");
});


const wss =
new WebSocket.Server({server});


let ristProcess=null;
let ristBuffer="";


let config={
    ip:"45.176.5.154",
    port:"7077",
    udp:"192.168.192.158:8181",
    buffer:"5000"
};



function wsSend(data)
{
    let msg=JSON.stringify(data);

    wss.clients.forEach(c=>{
        if(c.readyState===1)
            c.send(msg);
    });
}




function startRIST()
{

    if(ristProcess)
        return;


    let args=[

        "-i",
        `rist://${config.ip}:${config.port}`,

        "-o",
        `udp://${config.udp}`,

        "-p",
        "1",

        "-b",
        config.buffer

    ];


    console.log(args.join(" "));


    ristProcess=
    spawn(
        "ristreceiver",
        args
    );


    ristProcess.stdout.on(
        "data",
        parseRIST
    );


    ristProcess.stderr.on(
        "data",
        parseRIST
    );


    ristProcess.on(
        "close",
        ()=>{
            ristProcess=null;
        }
    );

}



function stopRIST()
{

    if(ristProcess)
    {
        ristProcess.kill("SIGTERM");
        ristProcess=null;
    }

}




function parseRIST(data)
{

    ristBuffer+=data.toString();

    let lines=
    ristBuffer.split("\n");


    ristBuffer=
    lines.pop();



    lines.forEach(line=>{


        let p=line.indexOf("{");

        if(p<0)
            return;


        try{


            let json=
            JSON.parse(
                line.substring(p)
            );


            if(json["receiver-stats"])
            {

                wsSend({

                    type:"rist",

                    data:
                    json["receiver-stats"]
                    .flowinstant

                });

            }



            if(json["flow_cumulative_stats"])
            {

                wsSend({

                    type:"cum",

                    data:
                    json["flow_cumulative_stats"]

                });

            }


        }
        catch(e){}


    });


}






app.post("/start",(req,res)=>{

    config=req.body;

    startRIST();

    res.json({
        ok:true
    });

});



app.post("/stop",(req,res)=>{

    stopRIST();

    res.json({
        ok:true
    });

});







async function systemStats()
{

    let cpu=
    await si.currentLoad();


    let mem=
    await si.mem();


    let proc=
    await si.processes();


    let net=
    await si.networkStats();



    wsSend({

        type:"system",

        data:{

            cpu:
            cpu.currentLoad,


            memory:
            (mem.used/mem.total)*100,


            memUsed:
            mem.used,


            memTotal:
            mem.total,


            processes:
            proc.all,


            rx:
            net[0]?.rx_sec || 0,


            tx:
            net[0]?.tx_sec || 0

        }

    });


}


setInterval(
systemStats,
2000
);
